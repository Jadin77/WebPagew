param(
  [int]$MaxPages = 2,
  [int]$DelayMs = 3500,
  [int]$MinIntervalMinutes = 10,
  [switch]$Force
)

$ErrorActionPreference = "Stop"

if ($MaxPages -lt 1) { throw "MaxPages must be at least 1." }
if ($DelayMs -lt 0) { throw "DelayMs cannot be negative." }
if ($MinIntervalMinutes -lt 0) { throw "MinIntervalMinutes cannot be negative." }

function Ensure-File {
  param([string]$Path, [string]$DefaultContent = "")
  if (-not (Test-Path $Path)) {
    Set-Content -Path $Path -Value $DefaultContent -Encoding utf8
  }
}

function Read-Lines {
  param([string]$Path)
  Ensure-File -Path $Path
  return @(
    Get-Content $Path |
      ForEach-Object { $_.Trim() } |
      Where-Object { $_ -and -not $_.StartsWith("#") }
  )
}

function Normalize-ImageUrl {
  param([object]$Value)
  if (-not ($Value -is [string])) { return $null }
  $url = $Value.Trim()
  if (-not $url) { return $null }
  if ($url.StartsWith("//")) { return "https:$url" }
  if ($url.StartsWith("/")) { return "https://scriptblox.com$url" }
  return $url
}

function Normalize-Text {
  param([string]$Text)
  if (-not $Text) { return "" }
  return ([regex]::Replace($Text.ToLowerInvariant(), "[^a-z0-9]+", ""))
}

function Build-KeywordRules {
  param([string[]]$Lines)
  $rules = @()
  foreach ($line in $Lines) {
    $tokens = @(
      ($line -split "\s+") |
      ForEach-Object { Normalize-Text $_ } |
      Where-Object { $_ }
    )
    if ($tokens.Count -gt 0) { $rules += ,$tokens }
  }
  return $rules
}

function Test-MatchByRules {
  param([string]$Title, [object[]]$Rules)
  $normalizedTitle = Normalize-Text $Title
  if (-not $normalizedTitle) { return $false }
  foreach ($tokens in $Rules) {
    $ok = $true
    foreach ($token in $tokens) {
      if (-not $normalizedTitle.Contains($token)) {
        $ok = $false
        break
      }
    }
    if ($ok) { return $true }
  }
  return $false
}

function Invoke-JsonWithRetry {
  param([string]$Uri, [int]$MaxAttempts = 5)
  $attempt = 0
  while ($attempt -lt $MaxAttempts) {
    try {
      return Invoke-RestMethod -Method Get -Uri $Uri
    } catch {
      $attempt++
      if ($attempt -ge $MaxAttempts) { throw }
      $waitSeconds = [Math]::Min(30, [Math]::Pow(2, $attempt))
      Write-Warning ("Request failed ({0}/{1}). Waiting {2}s. Uri: {3}" -f $attempt, $MaxAttempts, $waitSeconds, $Uri)
      Start-Sleep -Seconds $waitSeconds
    }
  }
  throw "Request failed for $Uri"
}

$statePath = Join-Path $PSScriptRoot "scriptblox-refresh-state.json"
if (-not $Force -and $MinIntervalMinutes -gt 0 -and (Test-Path $statePath)) {
  try {
    $state = Get-Content $statePath -Raw | ConvertFrom-Json
    if ($state.lastRunUtc) {
      $lastRun = [datetime]::Parse($state.lastRunUtc).ToUniversalTime()
      $nextAllowed = $lastRun.AddMinutes($MinIntervalMinutes)
      $nowUtc = (Get-Date).ToUniversalTime()
      if ($nowUtc -lt $nextAllowed) {
        $remaining = [Math]::Ceiling(($nextAllowed - $nowUtc).TotalSeconds)
        Write-Warning ("Skipped refresh to avoid rate limit. Try again in about {0} seconds or use -Force." -f $remaining)
        exit 0
      }
    }
  } catch {
    Write-Warning "Could not read refresh state file; continuing."
  }
}

$moderationDir = Join-Path $PSScriptRoot "moderation"
if (-not (Test-Path $moderationDir)) {
  New-Item -ItemType Directory -Path $moderationDir | Out-Null
}

$settingsPath = Join-Path $moderationDir "settings.json"
$blacklistKeywordsPath = Join-Path $moderationDir "blacklist-keywords.txt"
$trustedKeywordsPath = Join-Path $moderationDir "trusted-keywords.txt"
$autoBlacklistTitlesPath = Join-Path $moderationDir "auto-blacklist-titles.txt"
$autoLogPath = Join-Path $moderationDir "auto-blacklist-log.jsonl"

Ensure-File -Path $settingsPath -DefaultContent @"
{
  "max_posts_per_window": 5,
  "window_minutes": 10
}
"@
Ensure-File -Path $blacklistKeywordsPath -DefaultContent @"
# One keyword phrase per line.
# Any variation containing all words is blocked.
mm2 dupe
"@
Ensure-File -Path $trustedKeywordsPath -DefaultContent @"
# One trusted keyword phrase per line.
drivehub
ragerhub
"@
Ensure-File -Path $autoBlacklistTitlesPath -DefaultContent "# Auto-generated normalized titles`r`n"
Ensure-File -Path $autoLogPath

$settingsDefault = @{ max_posts_per_window = 5; window_minutes = 10 }
$settings = $settingsDefault
try {
  $parsed = Get-Content $settingsPath -Raw | ConvertFrom-Json
  if ($parsed.max_posts_per_window) { $settings.max_posts_per_window = [int]$parsed.max_posts_per_window }
  if ($parsed.window_minutes) { $settings.window_minutes = [int]$parsed.window_minutes }
} catch {
  Write-Warning "Invalid moderation/settings.json; using defaults."
}
$maxPostsPerWindow = [Math]::Max(1, [int]$settings.max_posts_per_window)
$windowMinutes = [Math]::Max(1, [int]$settings.window_minutes)

$blacklistRules = Build-KeywordRules -Lines (Read-Lines -Path $blacklistKeywordsPath)
$trustedRules = Build-KeywordRules -Lines (Read-Lines -Path $trustedKeywordsPath)
$autoTitleKeys = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
foreach ($line in (Read-Lines -Path $autoBlacklistTitlesPath)) { [void]$autoTitleKeys.Add($line) }

$baseApi = "https://scriptblox.com/api/script/fetch?mode=free&sortBy=createdAt&order=desc"
$bySlug = @{}
$totalPages = $null

for ($page = 1; $page -le $MaxPages; $page++) {
  $api = "$baseApi&page=$page"
  $data = $null
  try {
    $data = Invoke-JsonWithRetry -Uri $api -MaxAttempts 5
  } catch {
    Write-Warning ("Stopping at page {0}. Last error: {1}" -f $page, $_.Exception.Message)
    break
  }
  if (-not $data) { break }
  $result = $data.result
  if (-not $totalPages) { $totalPages = [int]$result.totalPages }
  $scripts = @($result.scripts)

  foreach ($s in $scripts) {
    $slug = [string]$s.slug
    if (-not $slug) { continue }
    if ($bySlug.ContainsKey($slug)) { continue }

    $img = Normalize-ImageUrl $s.image
    if (-not $img) { $img = Normalize-ImageUrl $s.imageUrl }
    if (-not $img -and $s.game) { $img = Normalize-ImageUrl $s.game.imageUrl }
    $title = [string]$s.title
    $titleKey = Normalize-Text $title
    $tags = @()
    if ($s.tags) { $tags = @($s.tags | Where-Object { $_ -ne $null -and "$_".Trim() -ne "" }) }

    $trusted = Test-MatchByRules -Title $title -Rules $trustedRules
    $manualBlacklisted = Test-MatchByRules -Title $title -Rules $blacklistRules

    $bySlug[$slug] = [PSCustomObject]@{
      title = $title
      titleKey = $titleKey
      slug = $slug
      views = [int]$s.views
      verified = [bool]$s.verified
      tags = $tags
      image = $img
      createdAt = [string]$s.createdAt
      trusted = [bool]$trusted
      blocked_manual_keyword = [bool]$manualBlacklisted
      blocked_spam = $false
    }
  }

  Write-Host ("Fetched page {0}/{1} | page items: {2} | unique scripts: {3}" -f $page, $totalPages, $scripts.Count, $bySlug.Count)
  if ($scripts.Count -eq 0) { break }
  if ($result.nextPage -eq $null) { break }
  if ($page -ge $totalPages) { break }
  if ($DelayMs -gt 0) { Start-Sleep -Milliseconds $DelayMs }
}

# Mark trending scripts using dedicated endpoint.
$trendingSlugs = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
$trendScripts = @()
try {
  $trendPayload = Invoke-JsonWithRetry -Uri "https://scriptblox.com/api/script/trending" -MaxAttempts 3
  if ($trendPayload.result -and $trendPayload.result.scripts) { $trendScripts = @($trendPayload.result.scripts) }
  foreach ($t in $trendScripts) {
    $slug = [string]$t.slug
    if ($slug) { [void]$trendingSlugs.Add($slug) }
  }
} catch {
  Write-Warning "Trending fetch failed this run; continuing without trending marks."
}

# Merge trending scripts into dataset so the Trending tab is never empty.
foreach ($t in $trendScripts) {
  $slug = [string]$t.slug
  if (-not $slug) { continue }
  if ($bySlug.ContainsKey($slug)) { continue }

  $img = Normalize-ImageUrl $t.image
  if (-not $img -and $t.game) { $img = Normalize-ImageUrl $t.game.imageUrl }
  $title = [string]$t.title
  $titleKey = Normalize-Text $title
  $tags = @()
  if ($t.tags) { $tags = @($t.tags | Where-Object { $_ -ne $null -and "$_".Trim() -ne "" }) }
  $trusted = Test-MatchByRules -Title $title -Rules $trustedRules
  $manualBlacklisted = Test-MatchByRules -Title $title -Rules $blacklistRules

  $bySlug[$slug] = [PSCustomObject]@{
    title = $title
    titleKey = $titleKey
    slug = $slug
    views = [int]$t.views
    verified = [bool]$t.verified
    tags = $tags
    image = $img
    createdAt = [string]$t.createdAt
    trusted = [bool]$trusted
    blocked_manual_keyword = [bool]$manualBlacklisted
    blocked_spam = $false
  }
}

$rawScripts = @($bySlug.Values | Sort-Object @{Expression = { $_.createdAt }; Descending = $true })
if ($rawScripts.Count -eq 0) {
  Write-Warning "No scripts fetched (likely temporary rate limit). Existing feed files were left unchanged."
  exit 1
}
foreach ($s in $rawScripts) {
  $s | Add-Member -NotePropertyName trending -NotePropertyValue ($trendingSlugs.Contains([string]$s.slug) ) -Force
}

# Anti-spam by repeated title key in configured time window.
$newAutoTitleKeys = @()
$groups = $rawScripts | Group-Object titleKey
foreach ($group in $groups) {
  $titleKey = [string]$group.Name
  if (-not $titleKey) { continue }
  $trustedGroup = $group.Group | Where-Object { $_.trusted -eq $true }
  if ($trustedGroup.Count -gt 0) { continue }

  $times = @(
    $group.Group |
      ForEach-Object { try { [datetime]$_.createdAt } catch { $null } } |
      Where-Object { $_ -ne $null } |
      Sort-Object
  )
  if ($times.Count -le $maxPostsPerWindow) { continue }

  $isSpam = $false
  for ($i = 0; $i -lt $times.Count; $i++) {
    $start = $times[$i]
    $countInWindow = 1
    for ($j = $i + 1; $j -lt $times.Count; $j++) {
      $diff = ($times[$j] - $start).TotalMinutes
      if ($diff -le $windowMinutes) { $countInWindow++ } else { break }
    }
    if ($countInWindow -gt $maxPostsPerWindow) { $isSpam = $true; break }
  }

  if ($isSpam -and -not $autoTitleKeys.Contains($titleKey)) {
    [void]$autoTitleKeys.Add($titleKey)
    $newAutoTitleKeys += $titleKey
  }
}

if ($newAutoTitleKeys.Count -gt 0) {
  $timestamp = (Get-Date).ToUniversalTime().ToString("o")
  foreach ($titleKey in ($newAutoTitleKeys | Sort-Object)) {
    $sample = ($rawScripts | Where-Object { $_.titleKey -eq $titleKey } | Select-Object -First 1).title
    $entry = [PSCustomObject]@{
      ts = $timestamp
      titleKey = $titleKey
      sampleTitle = $sample
      reason = "title_spam_burst"
      max_posts_per_window = $maxPostsPerWindow
      window_minutes = $windowMinutes
    } | ConvertTo-Json -Compress
    Add-Content -Path $autoLogPath -Value $entry
  }
}

$autoSorted = @($autoTitleKeys | Sort-Object)
if ($autoSorted.Count -gt 0) {
  $autoSorted | Set-Content -Path $autoBlacklistTitlesPath -Encoding utf8
}

$visibleScripts = @()
$filteredKeywordCount = 0
$filteredSpamCount = 0
foreach ($s in $rawScripts) {
  $autoBlocked = $s.titleKey -and $autoTitleKeys.Contains($s.titleKey)
  $s.blocked_spam = [bool]$autoBlocked

  if ($s.blocked_manual_keyword) {
    $filteredKeywordCount++
    continue
  }
  if ($s.blocked_spam -and -not $s.trusted) {
    $filteredSpamCount++
    continue
  }
  $visibleScripts += $s
}

$out = [PSCustomObject]@{
  source = "scriptblox"
  generatedAt = (Get-Date).ToUniversalTime().ToString("o")
  maxPagesRequested = $MaxPages
  totalPagesAtSource = $totalPages
  count = $visibleScripts.Count
  moderation = [PSCustomObject]@{
    max_posts_per_window = $maxPostsPerWindow
    window_minutes = $windowMinutes
    filteredByKeywordCount = $filteredKeywordCount
    filteredBySpamCount = $filteredSpamCount
    filteredCount = ($filteredKeywordCount + $filteredSpamCount)
    autoBlacklistedTitleCount = $autoTitleKeys.Count
    newlyAutoBlacklistedTitleCount = $newAutoTitleKeys.Count
    trustedKeywordRuleCount = $trustedRules.Count
    blacklistKeywordRuleCount = $blacklistRules.Count
    trendingCount = $trendingSlugs.Count
  }
  scripts = $visibleScripts
}

$jsonPath = Join-Path $PSScriptRoot "scriptblox-feed.json"
$jsonBackup = Join-Path $PSScriptRoot "scriptblox-feed.backup.json"
if (Test-Path $jsonPath) { Copy-Item -Path $jsonPath -Destination $jsonBackup -Force }
$out | ConvertTo-Json -Depth 8 | Set-Content -Path $jsonPath -Encoding utf8

$jsPath = Join-Path $PSScriptRoot "scriptblox-feed.js"
$jsBackup = Join-Path $PSScriptRoot "scriptblox-feed.backup.js"
if (Test-Path $jsPath) { Copy-Item -Path $jsPath -Destination $jsBackup -Force }
$jsonMin = $out | ConvertTo-Json -Depth 8 -Compress
"window.SCRIPTBLOX_FEED = $jsonMin;" | Set-Content -Path $jsPath -Encoding utf8

Write-Host "Done. Wrote $($visibleScripts.Count) visible scripts to:"
Write-Host " - $jsonPath"
Write-Host " - $jsPath"
Write-Host ("Filtered by keyword: {0}" -f $filteredKeywordCount)
Write-Host ("Filtered by spam: {0}" -f $filteredSpamCount)
Write-Host ("New auto-blacklisted titles this run: {0}" -f $newAutoTitleKeys.Count)

$stateOut = [PSCustomObject]@{
  lastRunUtc = (Get-Date).ToUniversalTime().ToString("o")
  maxPagesUsed = $MaxPages
  delayMsUsed = $DelayMs
  minIntervalMinutes = $MinIntervalMinutes
  count = $visibleScripts.Count
  filteredCount = ($filteredKeywordCount + $filteredSpamCount)
}
$stateOut | ConvertTo-Json -Depth 4 | Set-Content -Path $statePath -Encoding utf8
